package com.billr.tradesysv1.exceptions;

public class TradeEntryException extends Exception {
	
	public TradeEntryException(String s) 
	{ 
	    // Call constructor of parent Exception 
	    super(s); 
	} 
}